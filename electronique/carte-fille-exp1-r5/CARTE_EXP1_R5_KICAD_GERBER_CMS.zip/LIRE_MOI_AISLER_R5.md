# Smash Makers — Carte fille EXP1 V9 R5 CMS + cavalier JP1

Dossier du 15 novembre 2026, pour préparation d’un devis AISLER. PCB 95,25 × 50,8 mm, deux couches, FR4 1,6 mm, cuivre 35 µm. Fixations et positions des câbles identiques à la R4. Aucun EXP OUT. Firmware inchangé.

## Passage en CMS
23 composants CMS au recto : 11 résistances 0805, 7 condensateurs 0805, 2 condensateurs 1206, 2 diodes Schottky SMA et une LED verte 0805. Deux composants traversants sont à monter : la prise EXP1 J1 et la barrette JP1. Les six groupes de pastilles J3 à J8 restent destinés aux fils à souder, sans connecteurs ajoutés. Trois repères optiques sont prévus pour l’assemblage. Les dix résistances optionnelles R7 à R16 sont marquées DNP et exclues du montage.

Les composants possèdent un champ MPN dans le PCB. BOM_AISLER_R5.csv contient les références fabricant exactes, quantités et liens de fiches techniques. La disponibilité dans le catalogue AISLER et les prix n’ont pas été vérifiés dans un compte connecté. Ne pas considérer cette archive comme une commande validée.

## JP1 : choix entre protection et tension directe
JP1 est une barrette mâle 1×2 au pas de 2,54 mm, en parallèle de D3 uniquement. Le cavalier agit simultanément sur l’alimentation des deux encodeurs.

| Configuration | Effet |
|---|---|
| JP1 ouvert, cavalier retiré — configuration livrée | Le courant traverse D3 ; protection anti-retour avec baisse de tension dépendant du courant et de la température. |
| JP1 fermé, cavalier posé | D3 est contournée ; alimentation des encodeurs directement depuis J7-3, sans la chute de D3. La protection anti-retour de cette branche est contournée aussi. |

JP1-1 = sortie protégée ENC_VEXT ; JP1-2 = entrée ENC_5V_IN. Ni l’une ni l’autre n’est une masse. La pose du shunt n’a pas de sens de polarité. Elle ne sélectionne pas une seconde source et ne transforme pas la tension. La protection D2 côté EXP1 reste active. Modifier la configuration hors tension.

Barrette à monter : Würth 61300211121. Shunt amovible : Würth 60900213421, à fournir séparément selon Accessoire_cavalier_JP1.csv et à laisser retiré au départ. Le shunt est un accessoire sans emplacement de soudure : il n’est pas une ligne à placer automatiquement sur le PCB. Dans AISLER, prévoir son approvisionnement séparé ou le signaler comme accessoire au fabricant.

## Fonctions conservées
D1 indique le 5 V EXP1 après D2, avec R17 = 1 kΩ. D2/D3 sont des SS14-M3/61T, cathode pastille 1 à gauche, repérée par une barre. La cathode de la LED D1 est également la pastille 1 à gauche. Les condensateurs sont désormais tous céramiques non polarisés : C2/C4 sont des 10 µF 25 V X7R 1206. Leur capacité effective diminue sous tension ; leur découplage doit être confirmé au prototype.

R18 à R21 = 330 Ω sur A/B ; C6 à C9 = 100 pF C0G vers masse ; R3 à R6 = 4,7 kΩ vers 3,3 V externe. R1/R2 = 47 Ω sur UART. R7 à R16 ne sont pas montées ; J8-10, via R16 éventuelle, reste pris après D2.

## Câblage
| Groupe | Pastilles et fonction |
|---|---|
| J1 | EXP1 SKR Mini E3 V3 : 1 PB5 ENC1 A ; 2 PA15 ENC1 B ; 3 PA9 TX ; 4 RESET ; 5 PA10 ; 6 PB9 ENC2 A ; 7 PB8 ; 8 PD6 ENC2 B ; 9 GND ; 10 5 V |
| J3 | 1 Waveshare GPIO45 TX ; 2 GPIO46 RX ; 3 GND |
| J4 | 1 vers TFT PA3 RX SKR ; 2 GND |
| J5 | Encodeur 1 : 1 A ; 2 B ; 3 GND ; 4 alimentation ENC_VEXT |
| J6 | Encodeur 2 : 1 A ; 2 B ; 3 GND ; 4 alimentation ENC_VEXT |
| J7 | 1 source 3,3 V régulée externe ; 2 masse commune ; 3 entrée 5 V externe pour les encodeurs |
| JP1 | 1 ENC_VEXT ; 2 ENC_5V_IN ; court-circuit facultatif de D3 |
| J8 | Dix sorties optionnelles, non équipées en V9. Voir netlist. |

Le 3,3 V externe reste nécessaire aux rappels. Cette version suppose des encodeurs alimentés en 5 V, à sorties NPN collecteur ouvert compatibles avec des rappels 3,3 V. La confirmation de leur seule tension d’alimentation ne confirme pas le type de sortie. Ni le cavalier ni les résistances ne constituent une conversion de sorties actives 5 V vers 3,3 V. Les signaux GPIO ne sont pas isolés et peuvent laisser passer une alimentation parasite. Ne pas appliquer 5 V à J7-1.

## Utilisation chez AISLER
1. Téléverser SM_EXP1_V9_R5_CMS.kicad_pcb pour conserver les informations d’assemblage et les champs MPN. Le ZIP Gerber séparé sert au PCB nu, pas à lui seul à définir le montage.
2. Choisir le service d’assemblage Amazing Assembly. Vérifier l’affectation des 25 composants soudés : 23 CMS et deux barrettes/prises THT. Les trous H1/H2/H3, les repères FID1/FID2/FID3, les groupes de fils J3 à J8 et R7 à R16 sont exclus du montage.
3. Contrôler dans leur visualiseur les boîtiers, la cathode des trois diodes/LED, la broche 1 et le détrompeur de J1. Le modèle KiCad utilise des empreintes incluses ; toute substitution de référence nécessite de revoir le boîtier et la polarité.
4. Vérifier la fourniture séparée du shunt JP1 et le laisser non posé lors de la livraison. Le prix et la disponibilité se confirment dans AISLER avant commande.

Le fichier Positions_KiCad_R5.csv inclut les 25 composants soudés uniquement, tous au recto. Coordonnées en millimètres, origine au coin supérieur gauche du PCB, axe Y négatif vers le bas selon l’export KiCad ; les origines sont centrées sur les boîtiers. La rotation de placement doit être interprétée avec les empreintes du PCB, pas par une convention indépendante du fabricant.

La bibliothèque SM_EXP1_R5.pretty et fp-lib-table sont incluses. Ouvrir le projet KiCad et recalculer les zones avant un nouvel export. Fabrication contient Gerber, couche pâte F.Paste, perçages métallisés et non métallisés. Des trous métallisés sont nécessaires aux vias et aux traversants. La version n’est pas un masque de gravure laser simple face.

## Contrôles et limites
Contrôle KiCad 10.99 : aucune violation ni pastille non connectée dans la configuration fournie. La netlist de tous les composants antérieurs est identique à la R4 ; JP1 est ajouté uniquement entre les deux bornes de D3. Le nombre et les références des pièces de la BOM ont été comparés au fichier de placement et aux propriétés MPN du PCB. Les rapports et vues des deux faces sont inclus.

Il n’y a pas de schéma .kicad_sch soumis à ERC : le document fourni est un schéma fonctionnel de câblage. Aucun prototype, essai EMI, simulation SPICE ou test du firmware sur matériel n’a été réalisé. Avant connexion aux contrôleurs, mesurer le 3,3 V et le 5 V encodeur en charge, puis vérifier les impulsions à vitesse maximale et le dialogue UART. Le brochage provient de l’archive initiale : confirmer l’orientation de la nappe et le matériel réel avant branchement.

## Documentation consultée
- AISLER, montage traversant et CMS : https://aisler.net/en/products/assembly
- AISLER, import des références MPN : https://community.aisler.net/t/documenting-parts/56
- AISLER, format KiCad : https://community.aisler.net/t/kicad/88
- Fiches fabricant : liens dans la BOM et dans les propriétés des empreintes.

## Correction du routage près de D2
La branche parallèle superflue du réseau EXP1_5V_PROT près de D2 a été supprimée. Les segments strictement identiques superposés, même de sens opposé, ont été dédupliqués sur les deux faces. Il reste 680 segments. Le brochage, la BOM, JP1 et les valeurs sont inchangés. Gerber, vues et rapports ont été régénérés ; contrôle final sans violation ni pastille non connectée.
